The sudoku puzzles in this directory were obtained by hand from this site:
https://www.free-sudoku.com/sudoku.php

The degree of difficulty goes increasing as:
easy
medium
expert
evil

What they call evil are the minimal sudokus, having 17 clues, which were first collected by Gordon Royle. The not made for the purpose of human puzzles,but they have been verified to have unique completions.
No 16-clue sudoku exists as verified by Gary McGuire; so any feasible 16 placement of numbers is guaranteed to have more than one possible completion.

